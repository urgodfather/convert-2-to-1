<?php

class DB{
    public $db;
    private $config_file = '/home/xtreamcodes/iptv_xtream_codes/config';
    private $host;
    private $db_user;
    private $db_pass;
    private $db_name;

    public function __construct(){
        $config = json_decode(file_get_contents($this->config_file));
        unset($config->server_id);
        foreach($config as $key => $val){
            $this->$key = $val;
        }
    }

    public function connect(){
        $db = new Mysqli('localhost',$this->db_user,$this->db_pass,$this->db_name);
        if($db->connect_errno){
            die("DB CONNECTION ERROR: ".$db->connect_error);
        }else{
            $this->db = $db;
        }
    }

    public function xctables(){
        $db = $this->db;
        $db->query("USE information_schema");
        $tables = $db->query("SELECT TABLE_NAME FROM TABLES WHERE TABLE_SCHEMA='$this->db_name'");
        while($table = $tables->fetch_assoc()){
            $array[] = $table['TABLE_NAME'];
        }
        return $array;
    }
    private function idcolumn($table){
        $db = $this->db;
        $db->query("USE information_schema");
        $query = $db->query("SELECT COLUMN_NAME FROM COLUMNS WHERE TABLE_SCHEMA='$this->db_name' AND TABLE_NAME='$table' AND EXTRA='auto_increment'");
        $id = $query->fetch_array()[0];
        $db->query("USE $this->db_name");
        return $id;
    }
    public function fixcharset($array){
        foreach($array as $key => $value){
            $fixed_array[$key] = iconv('ISO-8859-1','UTF-8',$value);
        }
        return $fixed_array;
    }
    public function xc_fix(){
        $xctables = $this->xctables();
        $db = $this->db;
        foreach($xctables as $table){
            $auto_increment_col = $this->idcolumn($table);
            $tabledata = $db->query("SELECT * FROM $table");
            while($data = $tabledata->fetch_assoc()){
                $fixedData = $this->fixcharset($data);
                $this->insert($fixedData,$table,$auto_increment_col);
            }
        }
    }
    private function insert($array,$table,$id){
        $db = $this->db;
        $colsvals = null;
        $values = null;
        $i = 0;
        $c = count($array);
        foreach($array as $key=>$value){
            $colsvals .= "`$key`='$value',";
            $i++;
            if($i==$c){
                $colsvals = rtrim($colsvals,',');
            }
        }
        $db->query("UPDATE $table SET $colsvals WHERE $id=$array[$id]");
    }
}

$db = new DB;
$db->connect();
$db->xc_fix();